<html>
<body>
    <form method="POST" action="myresponse.php">
        Name: <input type="text" name="name"><br>
        Email: <input type="email" name="email"><br>
        Password: <input type="password" name="password">
        <input type="submit" value="Send Me">
    </form>

</body>

</html>
