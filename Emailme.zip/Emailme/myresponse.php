<html>

<body>
    Welcome <?php echo $_POST["name"]; ?><br>
    Your email address is: <?php echo $_POST["email"]; ?><br>
    Your password is: <?php echo $_POST["password"]; ?><br>
</body>
</html>